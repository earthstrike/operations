from gtts import gTTS
from tempfile import NamedTemporaryFile
import speech_recognition as sr
from pygame import mixer


def strip_specials(text):
    return ''.join(char for char in text if char.isalnum() or char == ' ')


def strip_specials_lower(text):
    return strip_specials(text).lower()


def play_audio(fp, sync=True):
    mixer.init()
    mixer.music.load(fp.name)
    mixer.music.play()
    if sync:
        while mixer.music.get_busy():
            continue

    # music = pyglet.media.load(file.name, streaming=False)
    # music.play()


def speak(text, accent='ru'):
    tts = gTTS(text=text, lang=accent)
    file = NamedTemporaryFile(suffix='.mp3')
    tts.save(file.name)
    # Play file
    play_audio(file)
    file.close()


def listen(noise_time=None):
    microphone = sr.Microphone()
    recogniser = sr.Recognizer()

    with microphone as source:
        audio = recogniser.listen(source)
        if noise_time:
            recogniser.adjust_for_ambient_noise(source, noise_time)
        text = recogniser.recognize_google(audio, language="en-GB")

    return text


def stop_music():
    mixer.music.stop()


def is_playing_music():
    return mixer.music.get_busy()
