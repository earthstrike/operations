import utils
from speech_recognition import UnknownValueError
from threading import Thread


class Trotsky:
    wake_words = ['Trotsky', 'Hey, Trotsky!', 'Da', 'Steve']

    def __init__(self, extra_wakes=[], accent='ru', override_wakes=False):
        self.stop_thread_running = False
        self.proc_running = False
        self.to_stop = False

        self.accent = accent
        if override_wakes:
            self.wake_words = []

        for wake in extra_wakes:
            self.wake_words.append(wake)

    def stop_thread(self):
        print("Initialising stop thread")
        while not self.proc_running:
            continue  # Wait until a process starts
        print("Starting Stop thread")
        self.stop_thread_running = True
        while self.proc_running:
            try:
                text = utils.listen()
                self.handle(text)
            except UnknownValueError:
                pass  # Do nothing
        print("Stopping stop thread")
        self.stop_thread_running = False

    def handle_stop(self, text):
        if 'stop' in utils.strip_specials_lower(text):
            print("STOOOHP")
            self.to_stop = True
            utils.speak("Da, stopping the music")

    def play_song(self, file_name):
        self.proc_running = True
        utils.play_audio(open(f'audio/{file_name}.ogg'), sync=False)
        while not self.to_stop and utils.is_playing_music():
            continue
        print("Attempting to stop the music")
        utils.stop_music()
        self.to_stop = False
        self.proc_running = False

    def play_song_action(self, file_name):
        return lambda: self.play_song(file_name)

    def loop(self):
        while True:
            try:
                text = utils.listen()
                self.handle(text)
            except UnknownValueError:
                pass  # Do nothing

    def handle(self, text):
        parsable = utils.strip_specials_lower(text)
        print(f"Parsable: {parsable}")
        for wake in self.wake_words:
            wake_parsable = utils.strip_specials_lower(wake)
            if parsable.startswith(wake_parsable):
                print("Contains wake word!")
                if self.stop_thread_running:
                    self.handle_stop(text)
                else:
                    self.perform(text=text, wake_word=wake)

    def perform(self, text, wake_word):
        parsable = utils.strip_specials_lower(text)
        wake_parsable = utils.strip_specials_lower(wake_word)

        response = "I do not know what to respond to that with"

        actions = []
        # Despacito
        if 'play despacito' in parsable:
            response = \
                "Da, this is much sad, I shall play the despacito in contribution to the rebellion against the state"
            actions.append(self.play_song_action('despacito'))
        elif 'so sad' in parsable:
            response = "Da, would you like me to play the despacito"

        elif ('nsa' in parsable or 'usa' in parsable or 'government' in parsable or 'mi' in parsable) \
                and ('spy' in parsable or 'track' in parsable) and 'me' in parsable:
            response = 'Da, you must other throw the state, the proletariat must no longer be kept as slaves under ' \
                       'the watch of the big brother government '

        elif 'play' in parsable and 'true' in parsable and (
                'international' in parsable or ('song' in parsable and 'proletariat' in parsable)):
            response = 'Da, the true song of the proletariat will be played'
            actions.append(self.play_song_action('unfair'))

        elif 'play' in parsable and ('international' in parsable or ('song' in parsable and 'proletariat' in parsable)):
            response = 'Da, I will play the song of the proletariat! We shall all rise up against the oppression of ' \
                       'the state my comrade! '
            actions.append(self.play_song_action('internationale'))

        elif 'take me home' in parsable:
            response = 'Da, I shall take you home, would you like me to take you home to West Virginia or Mother Russia'

        if parsable == wake_parsable:
            response = Trotsky.say_hello()

        utils.speak(response)
        for action in actions:
            stop_thread = Thread(target=self.stop_thread)
            stop_thread.start()
            action()
            stop_thread.join()

    @staticmethod
    def say_hello():
        return """\
        Da, I hear you loud and clear, for all intents and purposes, I am Trotsky, contributor to the revolution\
        """


trotsky = Trotsky()
trotsky.loop()
