extern crate log;
#[macro_use]
extern crate rust_embed;
#[macro_use(triple)]
extern crate target_lexicon;

pub mod lang;
pub mod parser;
pub mod compiler;
pub mod stdlib;

use std::env;
use compiler::CraneliftCompiler;
use std::path::*;

// TODO ~ Move all displaying of errors here
fn main() {
    let args: Vec<String> = env::args().collect();
    let file_name = args.get(1);
    if let Some(file_name) = file_name {
        let path = Path::new(&file_name);
        CraneliftCompiler::compile_file(path);
    }
}
