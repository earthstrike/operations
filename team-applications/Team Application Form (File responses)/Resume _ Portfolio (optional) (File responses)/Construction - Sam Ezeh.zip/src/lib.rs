extern crate log;
#[macro_use]
extern crate rust_embed;
#[macro_use(triple)]
extern crate target_lexicon;

pub mod lang;
pub mod compiler;
pub mod parser;
pub mod stdlib;

#[cfg(test)]
mod tests {
    use std::path::Path;
    use super::*;

    #[test]
    fn stdlib_test() {
        let compiler = compiler::CretonneCompiler::new();
        compiler::CretonneCompiler::compile_file("stdlib/assert.cn");
    }
}