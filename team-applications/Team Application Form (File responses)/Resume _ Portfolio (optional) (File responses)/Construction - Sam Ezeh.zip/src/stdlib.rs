#[derive(RustEmbed)]
#[folder("stdlib/")]
pub struct Libraries;