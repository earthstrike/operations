#[derive(Debug)]
pub enum FunctionVisibility {
    Default,
    Exported,
    Private
}

#[derive(Debug)]
pub enum Expression {
    /// An integer
    Integer(i32),
    /// A Boolean
    Boolean(bool),
    /// A character
    Char(u8),
    /// An Unsigned, 32 bit integer
    U32(u32),
    /// A Class Declaration
    ClassDeclaration(String, Vec<Expression>),
    /// A String Literal
    StringLiteral(String),
    /// A declaration of a function with its expressions
    Function(String, FunctionVisibility, Vec<Parameter>, Vec<Type>, Vec<Expression>),
    /// An assignment
    Assignment(String, Box<Expression>),
    /// Usage of a variable
    Variable(String),
    /// A return statement
    Return(Vec<Expression>),
    /// A Binary operation
    BinaryOperation(BinaryOperationType, Box<Expression>, Box<Expression>),
    /// A Unary Operation
    UnaryOperation(UnaryOperationType, Box<Expression>),
    /// An if statement
    IfStatement(Box<Expression>, Vec<Expression>, Vec<Expression>),
    /// A While loop
    WhileLoop(Box<Expression>, Vec<Expression>),
    /// A call to a function
    MethodCall(String, Vec<Expression>),
    /// An External functions declaration
    ExternalFunction(String, Vec<Type>, Vec<Type>),
    /// An Import statement
    Import(String, ImportLocation),
    /// The Nothing type
    NothingLiteral,
    /// A Pointer Literal
    PointerLiteral(i64),
    /// A Pointer expression
    PointerExpression(Box<Expression>),
    /// A Null Pointer
    NullPointer,
}


#[derive(Debug)]
pub enum ImportLocation {
    Global,
    Named(String),
}

#[derive(Clone, Debug)]
pub struct Parameter {
    pub name: String,
    pub typed: Type,
}

impl Parameter {
    pub fn new(name: String, typed: Type) -> Parameter {
        Parameter { name, typed }
    }
    pub fn signature(parameters: &Vec<Self>) -> Vec<Type> {
        parameters.iter().map({ |param| param.typed }).collect()
    }
}

#[derive(Debug)]
pub enum BinaryOperationType {
    Addition,
    Subtraction,
    Multiplication,
    Division,
    Modulo,
    Power,
    Equality,
    Inequality,
    LessThan,
    GreaterThan,
}

#[derive(Debug)]
pub enum UnaryOperationType {
    LogicalNegation,
    ArithmeticFactorial,
    ArithmeticNegation,
    Address,
}

impl Expression {
    pub fn int(&self) -> i32 {
        match self {
            &Expression::Integer(number) => number,
            _ => panic!("Tried to take a non-number as a number")
        }
    }
}

#[derive(Copy, Clone)]
#[derive(Debug)]
pub enum Type {
    Integer,
    String,
    Char,
    Boolean,
    U32,
    Pointer,
}