extern crate cranelift;
extern crate cranelift_frontend;
extern crate cranelift_native;
extern crate cranelift_codegen;
extern crate faerie;
extern crate target_lexicon;
extern crate goblin;
extern crate ansi_term;

use std::collections::HashMap;
use std::process::exit;
use std::str::FromStr;

use std::fs::File;
use std::path::Path;
use std::io::Read;

use self::target_lexicon::{Vendor, OperatingSystem, Environment, BinaryFormat};

use self::faerie::{Link, Artifact, ArtifactBuilder, Decl};
use self::faerie::Reloc as FaerieReloc;

use self::cranelift_codegen::settings;
use self::cranelift_codegen::entity::EntityRef;
use self::cranelift_codegen::ir::types::*;
use self::cranelift_codegen::ir::{ExternalName, Signature, Function, FuncRef, ExtFuncData, AbiParam, InstBuilder, Value, GlobalValueData, Ebb};
use self::cranelift_frontend::{FunctionBuilderContext, FunctionBuilder, Variable};
use self::cranelift_codegen::verifier::verify_function;
use self::cranelift_codegen::Context;
use self::cranelift_codegen::isa::TargetIsa;
use self::cranelift_codegen::binemit::RelocSink;
use self::cranelift_codegen::binemit::TrapSink;

use self::cranelift_codegen::isa::CallConv;

use self::cranelift_codegen::settings::Configurable;

use self::cranelift_codegen::ir::SourceLoc;
use self::cranelift_codegen::ir::TrapCode;

use self::cranelift_codegen::binemit::CodeOffset;
use self::cranelift_codegen::binemit::Reloc;
use self::cranelift_codegen::binemit::Addend;
use self::cranelift_codegen::ir::JumpTable;

use self::cranelift_codegen::ir::condcodes::IntCC::*;

use self::cranelift_codegen::ir::immediates::Imm64;

use self::ansi_term::Color::Red;

use lang::Expression;
use lang::Expression::*;
use lang::BinaryOperationType;
use lang::UnaryOperationType;
use lang::Parameter;
use lang::ImportLocation;
use lang::FunctionVisibility;
use lang;

use parser;
use stdlib;

// TODO: sort out some major code re-use

const POINTER_TYPE: Type = I64;
const STRING_NAMESPACE: u32 = 0;
const FUNCTION_NAMESPACE: u32 = 1;
const DEFAULT_FUNCTION_VISIBILITY: FunctionVisibility = FunctionVisibility::Private;
//const LAST_VALUE_VARIABLE_NAME: String =  "##last_Var".to_string();

// Macro to read the contents of a file
macro_rules! read {
    ($file:expr) => {{
        let mut string = String::new();
        let _ = $file.read_to_string(&mut string);

        // TODO: Return Result instead
        string
    }}
}

#[derive(Debug)]
pub enum CValue {
    Scalar(Value, lang::Type),
    Tuple(Vec<Value>, Vec<lang::Type>),
    Nothing,
}

use self::CValue::*;

trait HasExternalNameAndSignature {
    fn signature(&self) -> FunctionSignature;

    fn external_name(&self) -> ExternalName;

    fn compile_name(&self) -> String;
}

type FunctionData = (ExternalName, FunctionSignature);

impl HasExternalNameAndSignature for FunctionData {
    // TODO: clone?
    fn signature(&self) -> FunctionSignature {
        self.1.clone()
    }

    fn external_name(&self) -> ExternalName {
        self.0.clone()
    }

    fn compile_name(&self) -> String {
        let external_name = self.external_name();

        let s = external_name.to_string();
        match external_name {
            ExternalName::TestCase{length, ascii} => {
                s.get(1..s.len()).unwrap().to_string()
            }
            _ => external_name.to_string()
        }
    }
}

pub struct CraneliftCompiler {
    scope: HashMap<String, u32>,
    variables: HashMap<String, (usize, lang::Type)>,
    functions: HashMap<u32, FunctionData>,
    // TODO ~ remove?
    imports: HashMap<String, FuncRef>,
    var_index: usize,
    string_index: u32,
    function_index: u32,
    strings: HashMap<u32, String>,
    current_ebb: Option<Ebb>,
    terminated: bool,
}

struct ClassData {
    name: String,
    compiled_functions: Vec<CompiledFunction>,
    external_functions: Vec<ExternalFunction>,
}

impl ClassData {
    fn new(name: String, compiled_functions: Vec<CompiledFunction>, external_functions: Vec<ExternalFunction>) -> ClassData {
        println!("New Class created: {}", name);
        ClassData {
            name,
            compiled_functions,
            external_functions,
        }
    }
}

#[derive(Clone)]
struct ExternalFunction {
    scope_name: String,
    compile_name: String,
    external_name: ExternalName,
    signature: FunctionSignature,
}

impl ExternalFunction {
    fn new(scope_name: String, compile_name: String, external_name: ExternalName, signature: FunctionSignature) -> ExternalFunction {
        ExternalFunction { scope_name, compile_name, external_name, signature }
    }
}

#[derive(Clone)]
struct CompiledFunction {
    scope_name: String,
    external_name: ExternalName,
    compile_name: String,
    signature: FunctionSignature,
    code: Vec<u8>,
    sink: ConstructionRelocSink,
}

impl CompiledFunction {
    pub fn new(scope_name: String, compile_name: String, external_name: ExternalName, signature: FunctionSignature, code: Vec<u8>, sink: ConstructionRelocSink) -> CompiledFunction {
        CompiledFunction { scope_name, external_name, compile_name, signature, code, sink }
    }
}

struct ConstructionTrapSink;

impl ConstructionTrapSink {
    pub fn new() -> ConstructionTrapSink {
        ConstructionTrapSink {}
    }
}

impl TrapSink for ConstructionTrapSink {
    fn trap(&mut self, _: CodeOffset, _: SourceLoc, _: TrapCode) {
// unimplemented!()
    }
}

#[derive(Clone)]
struct ConstructionRelocSink {
    function_name: String,
    external_relocations: Vec<(String, CodeOffset)>,
    string_relocations: Vec<(u32, CodeOffset, Reloc, Addend)>,
}

impl RelocSink for ConstructionRelocSink {
    fn reloc_ebb(&mut self, _offset: CodeOffset, _relocation: Reloc, _: CodeOffset) {
        unimplemented!()
    }

    fn reloc_external(&mut self, offset: CodeOffset, relocation: Reloc, name: &ExternalName, addend: Addend) {
        println!("Reloc: {:?}", relocation);

        match name {
            &ExternalName::User {
                namespace: STRING_NAMESPACE,
                index
            } => {
                self.string_relocations.push((index, offset, relocation, addend));
            }

            &ExternalName::TestCase {
                length, ascii
            }
            => {
                let _ = (length, ascii);
                let mut name = name.to_string();
                let _ = name.remove(0); // removes '%'
                self.external_relocations.push((name, offset));
            }

            _ => ()
        }
    }

    fn reloc_jt(&mut self, _: CodeOffset, _: Reloc, _: JumpTable) {
        unimplemented!()
    }
}

impl ConstructionRelocSink {
    fn new(function_name: String) -> ConstructionRelocSink {
        ConstructionRelocSink { function_name, external_relocations: Vec::new(), string_relocations: Vec::new() }
    }
    fn add_links(&self, object: &mut Artifact) {
        for link in self.external_relocations.iter() {
// TODO ~ use result
            let _ = object.link(Link {
                from: &self.function_name,
                to: &link.0,
                at: link.1 as u64,
            });
        }

        for &(index, offset, relocation, addend) in self.string_relocations.iter() {
            let mut name = String::from("str.");
            name.push_str(&index.to_string());
            let _ = object.link_with(Link {
                from: &self.function_name,
                to: &name,
                at: offset as u64,
            }, FaerieReloc::Auto);
        }
    }
}


#[derive(Clone)]
struct FunctionSignature {
    params: Vec<lang::Type>,
    returns: Vec<lang::Type>,
}

impl FunctionSignature {
    fn new(params: Vec<lang::Type>, returns: Vec<lang::Type>) -> FunctionSignature {
        FunctionSignature { params, returns }
    }

    fn to_cranelift(&self) -> Signature {
        let mut signature = Signature::new(CallConv::SystemV);
        signature.params = self.params.iter().map(|param| AbiParam::new(CraneliftCompiler::visit_type(param))).collect();
        signature.returns = self.returns.iter().map(|rt| AbiParam::new(CraneliftCompiler::visit_type(rt))).collect();
        signature
    }
}

#[allow(unreachable_patterns)]
impl<'a> CraneliftCompiler {
    pub fn new() -> CraneliftCompiler {
        CraneliftCompiler { scope: HashMap::new(), imports: HashMap::new(), functions: HashMap::new(), variables: HashMap::new(), var_index: 0, string_index: 0, function_index: 0, strings: HashMap::new(), current_ebb: None, terminated: false }
    }

    fn reset(&mut self) {
        self.variables = HashMap::new();
        self.var_index = 0;
        self.imports = HashMap::new();
        self.terminated = false;
    }

    pub fn compile_file(file: &Path) {
        let mut compiler = CraneliftCompiler::new();
        if let Some(parent) = file.parent() {
            if let Ok(mut file) = File::open(file) {
                let mut contents = String::new();
                if let Ok(_) = file.read_to_string(&mut contents) {
                    compiler.compile(parent, contents);
                } else {
                    eprintln!("{}", Red.paint("Unable to read the file"));
                    exit(0)
                }
            } else {
                eprintln!("{}", Red.paint("Unable to open the  file"));
                exit(0);
            }
        } else {
            panic!("/*Cannot access parent dir*/")
        }
    }

    fn visit_name(name: String) -> ExternalName {
        ExternalName::testcase(name)
    }

    fn visit_type(typed: &lang::Type) -> Type {
        match typed {
            &lang::Type::Integer => I32,
            &lang::Type::U32 => I32,
            &lang::Type::Boolean => B1,
            &lang::Type::Char => I8,
            &lang::Type::String => POINTER_TYPE,
            &lang::Type::Pointer => POINTER_TYPE,
            _ => unimplemented!("Cannot use type {:?}", typed)
        }
    }

    fn visit_signature(params: Vec<lang::Type>, returns: Vec<lang::Type>) -> FunctionSignature {
        FunctionSignature::new(params, returns)
    }

    fn resolve_visibility(visibility: &FunctionVisibility) -> &FunctionVisibility {
        match visibility {
            &FunctionVisibility::Default => &DEFAULT_FUNCTION_VISIBILITY,
            _ => visibility.clone()
        }
    }

    fn compile(&mut self, _working_dir: &Path, programme: String) -> (Vec<CompiledFunction>, Vec<ExternalFunction>) { // TODO ~ global/non-global, private/public (functions)
        self.reset();

        let expressions = match parser::programme(&programme) {
            Ok(expressions) => {
                expressions
            }
            Err(error) => {
                eprintln!("{}\n{}", Red.paint("Experienced an error while parsing the file"), error);
                exit(0)
            }
        };
// Find functions
        for expression in expressions.iter() {
            match expression {
                &Expression::Function(ref name, ref visibility, ref params, ref returns, _) => {
                    let visibility = Self::resolve_visibility(visibility);

                    let external_name = match visibility {
                        &FunctionVisibility::Private => ExternalName::User { namespace: FUNCTION_NAMESPACE, index: self.function_index },
                        &FunctionVisibility::Exported => ExternalName::testcase(name),
                        _ => panic!("Could not resolve visibility {:?}", visibility)
                    };

                    let func_data = (external_name, Self::visit_signature(Parameter::signature(params), returns.to_owned()));

                    self.scope.insert(name.to_owned(), self.function_index);
                    self.functions.insert(self.function_index, func_data);
                }
                &ExternalFunction(ref name, ref params, ref returns) => {
                    let func_data = (Self::visit_name(name.to_owned()), Self::visit_signature(params.to_owned(), returns.to_owned()));

                    self.scope.insert(name.to_owned(), self.function_index);
                    self.functions.insert(self.function_index, func_data);
                }
                _ => ()
            }
            self.function_index += 1;
        }

        for expression in expressions.iter() {
            match expression {
                &Expression::ClassDeclaration(ref class_name, ref expressions) => {
                    for expression in expressions.iter() {
                        match expression {
                            &Expression::Function(ref func_name, ref visibility, ref func_params, ref func_returns, _) => {
                                let visibility = Self::resolve_visibility(visibility);
                                let mut scope_name = class_name.clone();
                                scope_name.push('.');
                                scope_name.push_str(func_name);
                                let scope_name = scope_name;

                                let external_name = match visibility {
                                    &FunctionVisibility::Exported => {
                                        let mut c_name = class_name.clone();
                                        c_name.push_str("__");
                                        c_name.push_str(func_name);
                                        ExternalName::testcase(c_name.clone())
                                    }
                                    &FunctionVisibility::Private => {
                                        ExternalName::User { namespace: FUNCTION_NAMESPACE, index: self.function_index }
                                    }
                                    _ => panic!("Could not resolve visibility {:?}", visibility)
                                };

                                let signature = Self::visit_signature(Parameter::signature(func_params), func_returns.clone());


                                self.scope.insert(scope_name, self.function_index);
                                self.functions.insert(self.function_index, (external_name, signature.clone()));
                                self.function_index += 1;
                            }
                            _ => ()
                        }
                    }
                }
                _ => ()
            }
        }

        let mut compiled_funcs: Vec<CompiledFunction> = Vec::new();
        let mut external_funcs: Vec<ExternalFunction> = Vec::new();
        let mut class_declarations: Vec<ClassData> = Vec::new();

        let function_builder_context = &mut FunctionBuilderContext::new();
        for expression in expressions {
            match expression {
                Function(name, _, params, returns, expressions) => {
                    let id = self.scope.get(&name).unwrap().clone(); // TODO: this is bad
                    let scope_name = name.to_owned();
                    let function_data = self.functions.get(&id).unwrap().to_owned();
                    let compile_name = function_data.compile_name();
                    let external_name = function_data.external_name();
                    let (function, isa) = self.visit_function(function_builder_context, external_name.clone(), params.clone(), returns.clone(), expressions);
                    let isa = isa.as_ref();
                    let function = function.to_owned();
                    let mut context = Context::for_function(function);
                    let res = context.compile(isa);
                    if let Ok(size) = res {
                        let mut relocsink = ConstructionRelocSink::new(scope_name.clone());
                        let mut trapsink = ConstructionTrapSink::new();
                        let mut buff = vec![0; size as usize];
                        unsafe { context.emit_to_memory(isa, buff.as_mut_ptr(), &mut relocsink, &mut trapsink); }
                        // TODO: to_owned? Change some stuff
                        compiled_funcs.push(CompiledFunction::new(scope_name, compile_name, external_name.clone(), Self::visit_signature(Parameter::signature(&params), returns), buff, relocsink)); // TODO ~ optional global
                    } else if let Err(error) = res {
                        panic!("Error: {}", error)
                    }
                }
                ExternalFunction(name, params, returns) => {
                    let id = self.scope.get(&name).unwrap();
                    let scope_name = name.to_owned();
                    let compile_name = scope_name.clone();
                    external_funcs.push(ExternalFunction::new(scope_name, compile_name, self.functions.get(id).unwrap().external_name(), Self::visit_signature(params, returns)));
                }
                ClassDeclaration(class_name, expressions) => {
                    let mut class_compiled_funcs = Vec::new();
                    for expression in expressions {
                        match expression {
                            Expression::Function(func_name, _, func_params, func_returns, func_expressions) => {
                                let mut scope_name = class_name.clone();
                                scope_name.push('.');
                                scope_name.push_str(&func_name);
                                let scope_name = scope_name;


                                let (compile_name, external_name) =
                                    {
                                        let id = self.scope.get(&scope_name).unwrap();
                                        let function_data = self.functions.get(id).unwrap();
                                        let compile_name = function_data.compile_name();
                                        let external_name = function_data.external_name();

                                        (compile_name, external_name)
                                    };


                                let (function, isa) = self.visit_function(function_builder_context, external_name.clone(), func_params.clone(), func_returns.clone(), func_expressions);
                                let isa = isa.as_ref();
                                let function = function.to_owned();
                                let mut context = Context::for_function(function);
                                let res = context.compile(isa);
                                if let Ok(size) = res {
                                    let mut relocsink = ConstructionRelocSink::new(func_name.clone());
                                    let mut trapsink = ConstructionTrapSink::new();
                                    let mut buff = vec![0; size as usize];
                                    unsafe { context.emit_to_memory(isa, buff.as_mut_ptr(), &mut relocsink, &mut trapsink); }

                                    // TODO ~ optional global

                                    let signature = Self::visit_signature(Parameter::signature(&func_params.clone()), func_returns.clone());
                                    let compiled_function = CompiledFunction::new(scope_name.clone(), compile_name, external_name.clone(), signature.clone(), buff, relocsink);
                                    class_compiled_funcs.push(compiled_function.clone());

                                    compiled_funcs.push(compiled_function);
                                } else if let Err(error) = res {
                                    panic!("Error: {}", error)
                                }
                            }
                            _ => panic!("Expected function or instance variable declaration")
                        }
                    }
                    class_declarations.push(ClassData::new(class_name, class_compiled_funcs, Vec::new()));
                }
                Import(name, location) => {
                    let mut file_name = name.clone();
                    if !file_name.ends_with(".cn") {
                        file_name.push_str(".cn");
                    }
                    let contents = match stdlib::Libraries::get(&file_name) {
                        Some(buffer) => String::from_utf8_lossy(&buffer).into_owned(),
                        None => {
                            match File::open(file_name) {
                                Ok(mut file) => read!(file),
//TODO: Use error
                                Err(_e) => panic!("Could not find/open library or file with that name"),
                            }
                        }
                    };

// TODO ~ use self compiler?
// TODO ~ Sort out clones? (not just here, with places that deal with signature and params mainly)
                    let mut compiler = CraneliftCompiler::new();
                    let (compiled_functions, external_functions) = compiler.compile(Path::new("/home/"), contents); // TODO ~ some sort of 'null' / empty dir?
                    for function in compiled_functions {
                        let scope_name = match &location {
                            &ImportLocation::Global => function.scope_name.clone(),
                            &ImportLocation::Named(ref namespace) => {
                                let mut scope_name = namespace.clone();
                                scope_name.push('.');
                                scope_name.push_str(&function.scope_name.to_owned());
                                scope_name
                            }
                        };
                        compiled_funcs.push(function.clone()); // add code
                        self.scope.insert(scope_name, self.function_index);
                        self.functions.insert(self.function_index, (function.external_name, function.signature.clone()));
                        self.function_index += 1;
                    }

                    for function in external_functions {
                        let scope_name = match &location {
                            &ImportLocation::Global => function.scope_name.clone(),
                            &ImportLocation::Named(ref namespace) => {
                                let mut scope_name = namespace.clone();
                                scope_name.push('.');
                                scope_name.push_str(&function.scope_name.to_owned());
                                scope_name
                            }
                        };
                        external_funcs.push(function.clone());
                        self.scope.insert(scope_name, self.function_index);
                        self.functions.insert(self.function_index, (function.external_name, function.signature.clone()));
                        self.function_index += 1;
                    }
                }
                _ => {
                    panic!("Expecting function, import or class declaration but instead found `{:?}`", expression);
                }
            }
        }

// TODO: use Results

        let file_name = String::from("output.o");
        let path = Path::new(&file_name);
        let file = File::create(path).unwrap();

// TODO: Customisation
        let mut target = triple!("x86_64");
        target.vendor = Vendor::Pc;
        target.operating_system = OperatingSystem::Linux;
        target.environment = Environment::Gnu;
        target.binary_format = BinaryFormat::Elf;

        let mut object = ArtifactBuilder::new(target).name("name".to_string()).finish();
        let _ = object.declarations(compiled_funcs.iter().map({ |function| (function.compile_name.clone(), Decl::Function { global: true }) }));
        let _ = object.declarations(external_funcs.iter().map({ |function| (function.compile_name.clone(), Decl::FunctionImport) }));
        let _ = object.declarations(self.strings.iter().map({
            |(id, _)|
                ({
                     let mut name = String::from("str.");
                     name.push_str(&id.to_string());
                     name
                 }, Decl::CString { global: true })
        }));
        for function in &compiled_funcs {
            let _ = object.define(function.compile_name.clone(), function.code.clone());
            function.sink.add_links(&mut object);
        }

        for (id, string) in self.strings.iter() {
            let mut name = String::from("str.");
            name.push_str(&id.to_string());
            let _ = object.define(name, string.to_owned().into_bytes());
        }

        let _ = object.write(file).unwrap();
        (compiled_funcs, external_funcs)
    }

    fn visit_char(function_builder: &mut FunctionBuilder, number: u8) -> CValue {
        return Scalar(function_builder.ins().iconst(I8, i64::from(number)), lang::Type::Char);
    }

    fn visit_unsigned32(function_builder: &mut FunctionBuilder, number: u32) -> CValue {
        return Scalar(function_builder.ins().iconst(I32, i64::from(number)), lang::Type::U32);
    }

    fn visit_while_loop(&mut self, function_builder: &mut FunctionBuilder, condition: &Expression, body: &Vec<Expression>) -> CValue { // TODO ~ Implement while loops
        let condition_check = function_builder.create_ebb();
        let while_body_ebb = function_builder.create_ebb();
        let continue_ebb = function_builder.create_ebb();
        function_builder.ins().jump(condition_check, &[]);
        function_builder.seal_block(self.current_ebb.unwrap());
        function_builder.switch_to_block(condition_check);
        let condition = self.visit_expression(function_builder, condition);
        let condition = match condition {
            Scalar(condition, lang::Type::Boolean) => condition,
            Scalar(condition, lang::Type::Integer) => condition,
            Scalar(condition, lang::Type::Pointer) => condition,
            _ => unimplemented!("Cannot handle xyz as condition in while loop") // TODO
        };
        function_builder.ins().brnz(condition, while_body_ebb, &[]);
        function_builder.ins().jump(continue_ebb, &[]);
        function_builder.seal_block(condition_check);

        function_builder.switch_to_block(while_body_ebb);
        for expression in body {
            self.visit_expression(function_builder, expression);
        }
        function_builder.ins().jump(condition_check, &[]);
        function_builder.seal_block(while_body_ebb);
        function_builder.switch_to_block(continue_ebb);
        self.current_ebb = Some(continue_ebb);


        Nothing
    }

    fn visit_expression(&mut self, mut function_builder: &mut FunctionBuilder, expression: &Expression) -> CValue {
        match expression {
            &Assignment(ref name, ref value) => self.visit_assignment(&mut function_builder, name.to_owned(), &value),
            &Integer(int) => Self::visit_integer(function_builder, int),
            &Expression::Variable(ref name) => self.visit_variable(function_builder, name),
            &Return(ref expressions) => self.visit_return(function_builder, expressions),
            &BinaryOperation(ref op, ref left_var, ref right_var) => self.visit_binary_operation(function_builder, op, &left_var, &right_var),
            &MethodCall(ref name, ref args) => self.visit_method_call(function_builder, name, args),
            &Boolean(boolean) => Self::visit_boolean(function_builder, boolean),
            &Char(number) => Self::visit_char(function_builder, number),
            &U32(number) => Self::visit_unsigned32(function_builder, number),
            &StringLiteral(ref string) => self.visit_string(function_builder, string),
            &IfStatement(ref condition, ref if_body, ref else_body) => self.visit_if_statement(function_builder, condition, if_body, else_body),
            &UnaryOperation(ref op, ref var) => self.visit_unary_operation(function_builder, op, &var),
            &PointerExpression(ref location) => self.visit_pointer_expression(function_builder, location),
            &PointerLiteral(location) => Self::visit_pointer_literal(function_builder, location),
            &NullPointer => Self::visit_null_pointer(function_builder),
            &WhileLoop(ref condition, ref body) => self.visit_while_loop(function_builder, condition, body),
            _ => unimplemented!("Currently cannot use the expression `{:?}`", expression)
        }
    }


    fn visit_null_pointer(function_builder: &mut FunctionBuilder) -> CValue {
        let zero = function_builder.ins().iconst(POINTER_TYPE, 0);
        Scalar(zero, lang::Type::Pointer)
    }
    fn visit_pointer_literal(function_builder: &mut FunctionBuilder, location: i64) -> CValue {
        let value = function_builder.ins().iconst(POINTER_TYPE, location);
        Scalar(value, lang::Type::Pointer)
    }

    fn visit_pointer_expression(&mut self, function_builder: &mut FunctionBuilder, location: &Expression) -> CValue {
        let location = self.visit_expression(function_builder, location);
        match location {
            Scalar(value, lang::Type::Integer) => Scalar(value, lang::Type::Pointer),
            /* Scalar(value, _)*/ _ => unimplemented!("Cannot create pointers from non-integer address")
        }
    }

    fn visit_if_statement(&mut self, function_builder: &mut FunctionBuilder, condition: &Expression, if_body: &Vec<Expression>, else_body: &Vec<Expression>) -> CValue {
        let condition = self.visit_expression(function_builder, condition);
        let condition = match condition {
            Scalar(condition, lang::Type::Boolean) => condition,
            Scalar(condition, lang::Type::Integer) => condition,
            Scalar(condition, lang::Type::Pointer) => condition,
            Scalar(_, _) => unimplemented!("Cannot have non-booleans as conditions in an if statement"),
            Nothing => panic!("Cannot have Nothing as a condition in an if statements"),
            Tuple(_, _) => unimplemented!("Cannot have tuples as a condition in if statements")
        };

        let if_true = function_builder.create_ebb(); // if it's true, we go here
        let continue_ebb = function_builder.create_ebb(); // afterwards continue here

        function_builder.ins().brnz(condition, if_true, &[]);
        let mut else_last_expression = None;
        if !else_body.is_empty() {
            let if_false = function_builder.create_ebb(); // if not we go here

            function_builder.ins().jump(if_false, &[]); // no condition, if we did branch, we wouldn't be here

            self.select_block(function_builder, if_false);
            for expression in else_body {
                let value = self.visit_expression(function_builder, expression);
                else_last_expression = Some(value);
            }

            if !self.terminated {
                function_builder.ins().jump(continue_ebb, &[]);
            }
            function_builder.seal_block(if_false);
        } else {
            function_builder.ins().jump(continue_ebb, &[]);
        }

        function_builder.seal_block(self.current_ebb.unwrap());

        self.select_block(function_builder, if_true);
        let mut if_last_expression = None;
        for expression in if_body {
            let value = self.visit_expression(function_builder, expression);
            if_last_expression = Some(value);
        }
        if !self.terminated {
            function_builder.ins().jump(continue_ebb, &[]);
        }
        function_builder.seal_block(if_true);

        self.select_block(function_builder, continue_ebb);

        self.current_ebb = Some(continue_ebb);
        Nothing // TODO ~ return last expression
    }

    fn select_block(&mut self, function_builder: &mut FunctionBuilder, ebb: Ebb) {
        function_builder.switch_to_block(ebb);
        self.terminated = false;
    }

    fn visit_string(&mut self, function_builder: &mut FunctionBuilder, string: &String) -> CValue {
        let index = self.string_index;
        self.string_index += 1;

        let mut string = string.to_owned();
        string.push('\0');

        self.strings.insert(index, string);
        let global_var = function_builder.create_global_value(GlobalValueData::Symbol { name: ExternalName::User { namespace: STRING_NAMESPACE, index }, offset: Imm64::new(0), colocated: true });

        let ptr = function_builder.ins().global_value(POINTER_TYPE, global_var);
        CValue::Scalar(ptr, lang::Type::String)
    }

    fn visit_method_call(&mut self, function_builder: &mut FunctionBuilder, name: &String, args: &Vec<Expression>) -> CValue { // TODO ~ passing tuples as arguments
// let func_ref = *self.imports.entry(name.clone()).or_insert( // ~ Caches imports
        println!("{:?}", self.scope);
        let id = match self.scope.get(name) {
            Some(id) => id.to_owned(),
            None => panic!("No function with name {} exists", name)
        };

        let (func_ref, signature) = match self.functions.get(&id) { // TODO: unwrap
            Some(&(ref ename, ref signature)) => {
                let func_data = ExtFuncData { name: ename.clone(), signature: function_builder.import_signature(signature.to_cranelift()), colocated: false };
                let func_ref = function_builder.import_function(func_data);
                (func_ref, signature.clone())
            }
            None => panic!("*No function with name {} exists", name) // TODO
        };
        let args: Vec<Value> = args.iter().map({
            |ref expression|
                match self.visit_expression(function_builder, &expression) {
                    Scalar(value, _) => value,
                    _ => unimplemented!("Tuples cannot be passed as function arguments")
                }
        }).collect();
        let call_result = function_builder.ins().call(func_ref, args.as_slice());
        let rvals = function_builder.inst_results(call_result);
        match rvals.len() {
            0 => CValue::Nothing,
            1 => Scalar(rvals[0], signature.returns[0]),
            _ => CValue::Tuple(rvals.to_vec(), signature.returns)
        }
    }

    fn visit_unary_operation(&mut self, function_builder: &mut FunctionBuilder, op_type: &UnaryOperationType, var: &'a Expression) -> CValue {
        let cval = self.visit_expression(function_builder, var);
        match cval {
            Scalar(value, ctype) => match op_type {
                &UnaryOperationType::LogicalNegation => {
                    match ctype {
                        lang::Type::Boolean => Scalar(function_builder.ins().bnot(value), lang::Type::Boolean),
                        _ => unimplemented!()
                    }
                }
                _ => unimplemented!()
            },
            Nothing => panic!("Cannot perform operations on Nothign"),
            Tuple(_, _) => panic!("Cannot perform unary operations on a Tuple")
        }
    }

    fn visit_binary_operation(&mut self, function_builder: &mut FunctionBuilder, op_type: &BinaryOperationType, left_var: &'a Expression, right_var: &'a Expression) -> CValue { // TODO ~ Not all values are ints
        let left_cval = self.visit_expression(function_builder, left_var); // TODO ~ What if 'tuple'
        let right_cval = self.visit_expression(function_builder, right_var);

        match left_cval {
            Scalar(left_value, lang::Type::Integer) => {
                match right_cval {
                    Scalar(right_value, lang::Type::Integer) => {
                        match op_type {
                            &BinaryOperationType::Addition => Scalar(function_builder.ins().iadd(left_value, right_value), lang::Type::Integer),
                            &BinaryOperationType::Multiplication => Scalar(function_builder.ins().imul(left_value, right_value), lang::Type::Integer),
                            &BinaryOperationType::Division => Scalar(function_builder.ins().imul(left_value, right_value), lang::Type::Integer),
                            &BinaryOperationType::Subtraction => Scalar(function_builder.ins().isub(left_value, right_value), lang::Type::Integer),
                            &BinaryOperationType::Modulo => Scalar(function_builder.ins().urem(left_value, right_value), lang::Type::Integer),
                            &BinaryOperationType::Equality => Scalar(function_builder.ins().icmp(Equal, left_value, right_value), lang::Type::Boolean),
                            &BinaryOperationType::Inequality => Scalar(function_builder.ins().icmp(NotEqual, left_value, right_value), lang::Type::Boolean),
                            &BinaryOperationType::LessThan => Scalar(function_builder.ins().icmp(SignedLessThan, left_value, right_value), lang::Type::Boolean),
                            &BinaryOperationType::GreaterThan => Scalar(function_builder.ins().icmp(SignedGreaterThan, left_value, right_value), lang::Type::Boolean),
                            &BinaryOperationType::Power => unimplemented!("Cannot use power operator"),//self.visit_method_call(function_builder, &String::from("pow"), &vec![*left_var.clone(), *right_var.clone()]),
                        }
                    } // TODO ~ More operations
                    _ => unimplemented!("Cannot perform operations on tuples!")
                }
            }
            Scalar(left_pointer, lang::Type::Pointer) => {
                match right_cval {
                    Scalar(right_pointer, lang::Type::Pointer) => {
                        match op_type {
                            &BinaryOperationType::Equality => Scalar(function_builder.ins().icmp(Equal, left_pointer, right_pointer), lang::Type::Boolean),
                            _ => unimplemented!("Cannot perform this operation")
                        }
                    }
                    _ => unimplemented!()
                }
            }
            _ => unimplemented!("Cannot perform operation `{:?}` on {:?} => {:?} and {:?} => {:?}", op_type, left_var, left_cval, right_var, right_var)
        }
    }

    fn visit_return(&mut self, function_builder: &mut FunctionBuilder, expressions: &Vec<Expression>) -> CValue {
        self.terminated = true; // terminated ebb
        let cvalues: Vec<CValue> = expressions.iter().map(|ref expression| self.visit_expression(function_builder, expression)).collect();
        let values: Vec<Value> = cvalues.iter().map(
            {
                |cvalue|
                    match cvalue {
                        &Scalar(value, _) => value,
                        &Nothing => unimplemented!("Cannot return nothing"),
                        _ => unimplemented!("Cannot return tuples")
                    }
            }).collect();
        function_builder.ins().return_(values.as_slice());
        CValue::Nothing
    }

    fn visit_integer(function_builder: &mut FunctionBuilder, int: i32) -> CValue {
        return Scalar(function_builder.ins().iconst(I32, i64::from(int)), lang::Type::Integer);
    }

    fn visit_boolean(function_builder: &mut FunctionBuilder, boolean: bool) -> CValue {
        return Scalar(function_builder.ins().bconst(B1, boolean), lang::Type::Boolean);
    }

    fn visit_variable(&self, function_builder: &mut FunctionBuilder, name: &String) -> CValue {
        if let Some(&(index, ctype)) = self.variables.get(name) {
            Scalar(function_builder.use_var(Variable::new(index)), ctype)
        } else {
            panic!("Attempted to access non-existent variable `{}`!", name)
        }
    }

    fn visit_assignment(&mut self, function_builder: &mut FunctionBuilder, name: String, value: &'a Expression) -> CValue { // TODO ~ tuple deconstruction
        let value = self.visit_expression(function_builder, value);

        let variable: Option<(usize, lang::Type)>;
        {
            let var = self.variables.get(&name);
            variable = if let Some(&(index_ref, ctype_ref)) = var {
                Some((index_ref, ctype_ref))
            } else {
                None
            }
        }
        let index =
            if let Some((index, _)) = variable {
                index
            } else {
                let index = self.var_index;
                let variable = Variable::new(index);
                self.var_index += 1;
                self.variables.insert(name, (variable.index(), match value {
                    Scalar(_, ctype) => ctype,
                    _ => unimplemented!()
                }));
                function_builder.declare_var(variable, match value {
                    Scalar(_, ctype) => match ctype {
                        lang::Type::Integer => I32,
                        lang::Type::Boolean => B1,
                        lang::Type::Char => I8,
                        lang::Type::String | lang::Type::Pointer => POINTER_TYPE,
                        _ => unimplemented!("Cannot assign of type {:?}", ctype)
                    },
                    Nothing => panic!("Cannot assign Nothing to a variable"),
                    _ => unimplemented!("Cannot assign a tuple to a variable")
                });
                index
            };
        function_builder.def_var(Variable::new(index), match value {
            Scalar(value, _) => value,
            CValue::Nothing => panic!("Cannot assign nothing to a variable!"),
            _ => unimplemented!("Cannot assign tuples to variables")
        });
        value
    }

    fn visit_function(&mut self, mut function_builder_context: &mut FunctionBuilderContext, external_name: ExternalName, params: Vec<Parameter>, returns: Vec<lang::Type>, expressions: Vec<Expression>) -> (Function, Box<TargetIsa>) {
        self.terminated = false;
        let implicit_return = returns.len() == 0;

        let signature = Self::visit_signature(Parameter::signature(&params), returns);
        let mut function = Function::with_name_signature(external_name, signature.to_cranelift());
        let mut function_builder = FunctionBuilder::new(&mut function, &mut function_builder_context);
        let entry = function_builder.create_ebb();
        self.current_ebb = Some(entry);

        function_builder.append_ebb_params_for_function_params(entry);
        function_builder.switch_to_block(entry);
        let param_vals = function_builder.ebb_params(entry).to_owned(); // TODO ~ does this 'work', what about when global vars come along?
        for (parameter, value) in params.iter().zip(param_vals) {
            let index = self.var_index; // move assignment elsewhere
            let variable = Variable::new(index);
            self.var_index += 1;
            self.variables.insert(parameter.name.clone(), (variable.index(), parameter.typed));
            function_builder.declare_var(variable, Self::visit_type(&parameter.typed));

            function_builder.def_var(variable, value);
        }
        for expression in expressions {
            self.visit_expression(&mut function_builder, &expression);
        }

        if !self.terminated {
            if implicit_return {
                self.visit_return(&mut function_builder, &Vec::new());
            } else {
                eprintln!("Function may never return but should return a value");
            }
        }

        function_builder.seal_block(self.current_ebb.unwrap());
        function_builder.finalize();

        let function = function_builder.func;

        let builder = cranelift_native::builder().unwrap();
        let mut settings = settings::builder();
        settings.enable("is_pic").expect("Was unable to enable pic");
        println!("IR:\n{}", function.display(None));
        let flags = settings::Flags::new(settings);
        let foi = settings::FlagsOrIsa { flags: &(flags.clone()), isa: None };
        let res = verify_function(function, foi);
        let isa = builder.finish(flags);
        match res {
            Ok(_) => { (function.to_owned(), isa) }
            Err(err) => panic!("{}", err),
        }
    }
}
