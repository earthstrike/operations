extern crate peg;

//TODO ~ test-compile each stdlib file
fn main() {
    println!("cargo:rerun-if-changed=stdlib");
    peg::cargo_build("src/construction.rustpeg");
}